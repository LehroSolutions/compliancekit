# ComplianceKit (core scaffold)

Initial open-source core aligned to `TOOLS-OPENSOURCE/.docs/compliancekit/BUILD.md`.

Current release: `1.0.0` (2026-03-02).

## Included now
- South African PII pattern detection (ID, passport, phone, company reg, etc.)
- Context-aware bank account and tax number detection
- POPIA-aligned risk summary generation
- CLI for scanning text files or stdin

## Quick usage
```bash
python -m pip install -e .
compliancekit --file sample.txt
```

## Local quality gate
```bash
python -m unittest discover -s tests -p "test_*.py" -v
```

## Release process
- Changelog: `CHANGELOG.md`
- Pre-release checks: `RELEASE_CHECKLIST.md`

## Full App (Frontend + Backend)
- Copy env: `cp .env.example .env` (or set env vars in your shell)
- Start: `python webapp/server.py`
- Open: `http://127.0.0.1:5101`

## Auth + v2 API
- Login: `POST /api/auth/login` with `{ "username":"<APP_USER>", "password":"<APP_PASS>" }`
- Bearer token (`API_TOKEN`) required for:
  - `GET /api/v2/scans`
  - `POST /api/v2/scans`
- Frontend includes login + v2 scan history panel.

## Production hardening defaults
- `APP_ENV=production` blocks insecure defaults for `APP_PASS` and `AUTH_SALT`.
- Request bodies are capped via `MAX_BODY_BYTES` (default: `1048576`).
- API and HTML responses include baseline security headers (`X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Cache-Control`).

## Domain v2 Endpoints
- `GET/POST/PATCH /api/v2/remediations`
- `GET/POST /api/v2/policies`
- `GET/POST /api/v2/report-jobs`

## Persistence + Release Assets
- Server now uses SQLite when available and falls back to `webapp/data.json` when SQLite is unavailable.
- `/api/ready` reports the active backend (`sqlite` or `json-file`).
- Added `Dockerfile`, `.env.example`, and `.github/workflows/ci.yml`.

